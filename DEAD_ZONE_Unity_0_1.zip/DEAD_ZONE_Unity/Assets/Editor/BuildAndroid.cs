using UnityEditor;
using UnityEditor.Build.Reporting;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;
using DeadZone;
using System.IO;

namespace DeadZone.Editor
{
    public static class BuildAndroid
    {
        public static void Build()
        {
            EditorUserBuildSettings.SwitchActiveBuildTarget(BuildTargetGroup.Android, BuildTarget.Android);
            PlayerSettings.companyName = "Codcito Studio";
            PlayerSettings.productName = "DEAD ZONE";
            PlayerSettings.SetApplicationIdentifier(BuildTargetGroup.Android, "com.codcito.deadzone");
            PlayerSettings.bundleVersion = "0.1.0";
            PlayerSettings.Android.bundleVersionCode = 1;
            PlayerSettings.Android.targetArchitectures = AndroidArchitecture.ARM64;
            PlayerSettings.defaultInterfaceOrientation = UIOrientation.LandscapeLeft;
            PlayerSettings.Android.minSdkVersion = AndroidSdkVersions.AndroidApiLevel23;
            PlayerSettings.Android.targetSdkVersion = AndroidSdkVersions.AndroidApiLevelAuto;
            PlayerSettings.colorSpace = ColorSpace.Gamma;
            string scenePath = "Assets/Scenes/DEAD_ZONE_Main.unity";
            CreateScene(scenePath);
            EditorBuildSettings.scenes = new[] { new EditorBuildSettingsScene(scenePath, true) };
            string output = "build/Android/DEAD_ZONE.apk";
            Directory.CreateDirectory("build/Android");
            BuildPlayerOptions options = new BuildPlayerOptions
            {
                scenes = new[] { scenePath },
                locationPathName = output,
                target = BuildTarget.Android,
                options = BuildOptions.CompressWithLz4
            };
            BuildReport report = BuildPipeline.BuildPlayer(options);
            if (report.summary.result != BuildResult.Succeeded)
                throw new System.Exception("Android build failed: " + report.summary.result + "; errors=" + report.summary.totalErrors);
            Debug.Log("DEAD ZONE APK created: " + output);
        }
        static void CreateScene(string path)
        {
            Scene scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
            RenderSettings.ambientLight = new Color(0.28f, 0.28f, 0.3f);
            GameObject light = new GameObject("Moonlight");
            light.transform.rotation = Quaternion.Euler(50, -30, 0);
            Light dl = light.AddComponent<Light>(); dl.type = LightType.Directional; dl.intensity = 0.75f;

            GameObject floor = GameObject.CreatePrimitive(PrimitiveType.Plane);
            floor.name = "Damaged street"; floor.transform.localScale = new Vector3(5, 1, 5);
            floor.GetComponent<Renderer>().material.color = new Color(0.22f, 0.23f, 0.22f);
            MakeBlock("Station", new Vector3(0, 2, 12), new Vector3(14, 4, 5), new Color(0.3f, 0.28f, 0.23f));
            MakeBlock("Pump island A", new Vector3(-4, 0.8f, 2), new Vector3(1.4f, 1.6f, 1.2f), new Color(0.65f, 0.25f, 0.12f));
            MakeBlock("Pump island B", new Vector3(4, 0.8f, 2), new Vector3(1.4f, 1.6f, 1.2f), new Color(0.65f, 0.25f, 0.12f));
            MakeBlock("Road barrier", new Vector3(0, 0.6f, -22), new Vector3(48, 1.2f, 1), Color.gray);
            MakeBlock("Side wall left", new Vector3(-24, 1.5f, 0), new Vector3(1, 3, 48), Color.gray);
            MakeBlock("Side wall right", new Vector3(24, 1.5f, 0), new Vector3(1, 3, 48), Color.gray);

            GameObject player = new GameObject("Player"); player.transform.position = new Vector3(0, 1, -5);
            CharacterController cc = player.AddComponent<CharacterController>(); cc.height = 1.8f; cc.radius = 0.35f;
            GameObject camObj = new GameObject("Player Camera"); camObj.transform.SetParent(player.transform); camObj.transform.localPosition = new Vector3(0, 0.6f, 0);
            Camera cam = camObj.AddComponent<Camera>(); cam.fieldOfView = 78; cam.tag = "MainCamera";
            PlayerController pc = player.AddComponent<PlayerController>(); pc.playerCamera = cam;

            GameObject gm = new GameObject("Game Manager"); GameManager manager = gm.AddComponent<GameManager>(); manager.player = player.transform;
            gm.AddComponent<MobileHUD>();
            EditorSceneManager.SaveScene(scene, path);
        }
        static void MakeBlock(string name, Vector3 pos, Vector3 scale, Color color)
        {
            GameObject go = GameObject.CreatePrimitive(PrimitiveType.Cube); go.name = name; go.transform.position = pos; go.transform.localScale = scale;
            go.GetComponent<Renderer>().material.color = color;
        }
    }
}
