using UnityEngine;
using System.Collections.Generic;

namespace DeadZone
{
    public class GameManager : MonoBehaviour
    {
        public static GameManager Instance;
        public Transform player;
        public int round = 1;
        public int points = 500;
        public int kills = 0;
        public int playerHealth = 100;
        public bool gameOver;
        public readonly List<ZombieAI> zombies = new List<ZombieAI>();
        float nextWaveTimer;

        void Awake() { Instance = this; }
        void Start() { SpawnWave(); }
        void Update()
        {
            zombies.RemoveAll(z => z == null);
            if (gameOver) return;
            if (zombies.Count == 0)
            {
                nextWaveTimer += Time.deltaTime;
                if (nextWaveTimer > 3f) { round++; nextWaveTimer = 0f; SpawnWave(); }
            }
        }
        void SpawnWave()
        {
            int count = 4 + round * 2;
            for (int i = 0; i < count; i++)
            {
                float angle = (Mathf.PI * 2f * i) / count;
                Vector3 pos = new Vector3(Mathf.Cos(angle) * 17f, 0.9f, Mathf.Sin(angle) * 17f);
                GameObject z = GameObject.CreatePrimitive(PrimitiveType.Capsule);
                z.name = "Zombie";
                z.transform.position = pos;
                z.transform.localScale = new Vector3(0.8f, 1.1f, 0.8f);
                z.GetComponent<Renderer>().material.color = new Color(0.25f, 0.42f, 0.28f);
                CapsuleCollider c = z.GetComponent<CapsuleCollider>(); c.isTrigger = false;
                Rigidbody rb = z.AddComponent<Rigidbody>(); rb.isKinematic = true; rb.useGravity = false;
                ZombieAI ai = z.AddComponent<ZombieAI>(); ai.health = 90 + round * 12;
                zombies.Add(ai);
            }
        }
        public void ZombieKilled(ZombieAI zombie)
        {
            if (zombies.Contains(zombie)) zombies.Remove(zombie);
            kills++; points += 100;
        }
        public void DamagePlayer(int amount)
        {
            if (gameOver) return;
            playerHealth = Mathf.Max(0, playerHealth - amount);
            if (playerHealth == 0) gameOver = true;
        }
    }
}
