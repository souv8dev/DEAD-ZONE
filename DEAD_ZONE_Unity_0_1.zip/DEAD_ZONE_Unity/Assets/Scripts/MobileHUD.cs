using UnityEngine;

namespace DeadZone
{
    public class MobileHUD : MonoBehaviour
    {
        GUIStyle label, button, title;
        void EnsureStyles()
        {
            if (label != null) return;
            label = new GUIStyle(GUI.skin.label) { fontSize = Mathf.Max(16, Screen.width / 42), fontStyle = FontStyle.Bold, normal = { textColor = Color.white } };
            button = new GUIStyle(GUI.skin.button) { fontSize = Mathf.Max(18, Screen.width / 38), fontStyle = FontStyle.Bold };
            title = new GUIStyle(label) { fontSize = Mathf.Max(24, Screen.width / 28), alignment = TextAnchor.MiddleCenter };
        }
        void OnGUI()
        {
            EnsureStyles();
            GameManager gm = GameManager.Instance;
            if (gm == null) return;
            GUI.Label(new Rect(18, 12, 260, 38), "RONDA " + gm.round, title);
            GUI.Label(new Rect(18, 52, 260, 32), "PUNTOS: " + gm.points, label);
            GUI.Label(new Rect(18, 84, 260, 32), "BAJAS: " + gm.kills, label);
            GUI.Label(new Rect(18, 116, 260, 32), "SALUD: " + gm.playerHealth, label);
            Rect fireRect = new Rect(Screen.width - 190, Screen.height - 160, 165, 120);
            if (GUI.Button(fireRect, "DISPARAR", button)) FindObjectOfType<PlayerController>()?.QueueFire();
            if (gm.gameOver)
            {
                GUI.Box(new Rect(0, 0, Screen.width, Screen.height), "");
                GUI.Label(new Rect(0, Screen.height * 0.35f, Screen.width, 70), "FIN DE LA PARTIDA", title);
                GUI.Label(new Rect(0, Screen.height * 0.45f, Screen.width, 50), "Ronda alcanzada: " + gm.round, title);
            }
        }
    }
}
