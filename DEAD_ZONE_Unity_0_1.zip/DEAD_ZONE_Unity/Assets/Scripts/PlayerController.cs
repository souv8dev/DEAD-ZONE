using UnityEngine;

namespace DeadZone
{
    [RequireComponent(typeof(CharacterController))]
    public class PlayerController : MonoBehaviour
    {
        public Camera playerCamera;
        public float moveSpeed = 5f;
        public float lookSpeed = 0.12f;
        CharacterController controller;
        float pitch;
        int moveFinger = -1, lookFinger = -1;
        Vector2 moveStart, moveCurrent;
        Vector2 lookLast;
        bool fireQueued;
        void Awake() { controller = GetComponent<CharacterController>(); }
        void Update()
        {
            Vector2 move = Vector2.zero;
            float yaw = 0f, pitchDelta = 0f;
            if (Application.isMobilePlatform)
            {
                for (int i = 0; i < Input.touchCount; i++)
                {
                    Touch t = Input.GetTouch(i);
                    if (t.phase == TouchPhase.Began)
                    {
                        if (t.position.x < Screen.width * 0.48f && moveFinger < 0) { moveFinger = t.fingerId; moveStart = t.position; moveCurrent = t.position; }
                        else if (t.position.x >= Screen.width * 0.48f && lookFinger < 0) { lookFinger = t.fingerId; lookLast = t.position; }
                    }
                    if (t.fingerId == moveFinger)
                    {
                        moveCurrent = t.position;
                        if (t.phase == TouchPhase.Ended || t.phase == TouchPhase.Canceled) moveFinger = -1;
                    }
                    if (t.fingerId == lookFinger)
                    {
                        if (t.phase == TouchPhase.Moved) { Vector2 d = t.position - lookLast; yaw += d.x * lookSpeed; pitchDelta -= d.y * lookSpeed; }
                        lookLast = t.position;
                        if (t.phase == TouchPhase.Ended || t.phase == TouchPhase.Canceled) lookFinger = -1;
                    }
                }
                if (moveFinger >= 0) { Vector2 d = (moveCurrent - moveStart) / 100f; move = Vector2.ClampMagnitude(d, 1f); }
            }
            else
            {
                move = new Vector2(Input.GetAxisRaw("Horizontal"), Input.GetAxisRaw("Vertical"));
                yaw = Input.GetAxis("Mouse X") * 2.2f;
                pitchDelta = -Input.GetAxis("Mouse Y") * 2.2f;
                if (Input.GetMouseButtonDown(0)) Fire();
            }
            transform.Rotate(0f, yaw, 0f);
            pitch = Mathf.Clamp(pitch + pitchDelta, -75f, 75f);
            if (playerCamera != null) playerCamera.transform.localRotation = Quaternion.Euler(pitch, 0, 0);
            Vector3 direction = transform.right * move.x + transform.forward * move.y;
            if (controller != null) controller.Move((direction * moveSpeed + Vector3.down * 9f) * Time.deltaTime);
            if (fireQueued) { fireQueued = false; Fire(); }
        }
        public void QueueFire() { fireQueued = true; }
        void Fire()
        {
            if (playerCamera == null || GameManager.Instance == null || GameManager.Instance.gameOver) return;
            if (Physics.Raycast(playerCamera.transform.position, playerCamera.transform.forward, out RaycastHit hit, 35f))
            {
                ZombieAI z = hit.collider.GetComponent<ZombieAI>();
                if (z != null) { z.Hit(50); GameManager.Instance.points += 10; }
            }
        }
    }
}
