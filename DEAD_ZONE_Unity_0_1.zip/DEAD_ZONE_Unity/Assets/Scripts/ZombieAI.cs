using UnityEngine;

namespace DeadZone
{
    public class ZombieAI : MonoBehaviour
    {
        public int health = 100;
        public float speed = 1.5f;
        float attackCooldown;
        Transform target;
        void Start() { if (GameManager.Instance != null) target = GameManager.Instance.player; }
        void Update()
        {
            if (GameManager.Instance == null || GameManager.Instance.gameOver || target == null) return;
            Vector3 delta = target.position - transform.position; delta.y = 0;
            if (delta.magnitude > 1.35f)
            {
                transform.position += delta.normalized * speed * Time.deltaTime;
                if (delta.sqrMagnitude > 0.01f) transform.rotation = Quaternion.LookRotation(delta.normalized);
            }
            else
            {
                attackCooldown -= Time.deltaTime;
                if (attackCooldown <= 0f) { GameManager.Instance.DamagePlayer(8); attackCooldown = 1.1f; }
            }
        }
        public void Hit(int damage)
        {
            health -= damage;
            if (health <= 0)
            {
                GameManager.Instance?.ZombieKilled(this);
                Destroy(gameObject);
            }
        }
    }
}
