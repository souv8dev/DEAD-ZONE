DEAD ZONE 0.1 — proyecto Unity para Android

Versión de Unity: 2022.3.62f1
Salida prevista: build/Android/DEAD_ZONE.apk
Arquitectura: ARM64

IMPORTANTE
- Es un prototipo inicial de bloques 3D; no contiene arte ni audio final.
- La escena se genera automáticamente durante la compilación mediante Assets/Editor/BuildAndroid.cs.
- Este ZIP no contiene un APK compilado.
- La compilación automatizada requiere una licencia Unity Personal válida configurada como secreto UNITY_LICENSE en GitHub Actions.

CONTROLES
- Android: lado izquierdo de la pantalla para moverse; lado derecho para mirar; botón DISPARAR.
- Editor/PC: WASD, mouse y clic izquierdo.

PARA COMPILAR CON GAMECI
1. Sube este ZIP al repositorio de GitHub.
2. Crea en el repositorio el workflow .github/workflows/build-android.yml usando las instrucciones que acompañan al proyecto.
3. Añade el secreto UNITY_LICENSE con una licencia .ulf válida de Unity.
4. Ejecuta Actions > Build DEAD ZONE APK > Run workflow.
5. Descarga el artefacto DEAD-ZONE-APK.
